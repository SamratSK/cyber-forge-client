import { Component } from '@angular/core';

@Component({
  selector: 'ng-reports',
  standalone: false,
  
  templateUrl: './reports.component.html',
  styleUrl: './reports.component.scss'
})
export class ReportsComponent {

}

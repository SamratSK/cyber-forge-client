import { Component } from '@angular/core';

@Component({
  selector: 'ng-first-aid',
  standalone: false,
  
  templateUrl: './first-aid.component.html',
  styleUrl: './first-aid.component.scss'
})
export class FirstAidComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'ng-resources',
  standalone: false,
  
  templateUrl: './resources.component.html',
  styleUrl: './resources.component.scss'
})
export class ResourcesComponent {

}

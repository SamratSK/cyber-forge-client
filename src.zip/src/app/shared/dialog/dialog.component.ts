import { Component } from '@angular/core';

@Component({
  selector: 'ng-dialog',
  standalone: false,
  
  templateUrl: './dialog.component.html',
  styleUrl: './dialog.component.scss'
})
export class DialogComponent {

}
